const texto = document.getElementById("texto");
const opcoes = document.getElementById("opcoes");

function mostrarCena(cena) {
  texto.innerText = cena.texto;
  opcoes.innerHTML = "";
  cena.opcoes.forEach(opcao => {
    let botao = document.createElement("button");
    botao.innerText = opcao.texto;
    botao.onclick = () => mostrarCena(cenas[opcao.proximo]);
    opcoes.appendChild(botao);
  });
}

const cenas = {
  inicio: {
    texto: "Você acorda em uma floresta misteriosa. O que deseja fazer?",
    opcoes: [
      { texto: "Seguir pelo caminho iluminado 🌞", proximo: "caminho" },
      { texto: "Explorar a caverna escura 🕳️", proximo: "caverna" }
    ]
  },
  caminho: {
    texto: "Você encontra uma vila pacífica. Final feliz 🎉",
    opcoes: [{ texto: "Recomeçar", proximo: "inicio" }]
  },
  caverna: {
    texto: "Um dragão aparece! Final dramático 🐉🔥",
    opcoes: [{ texto: "Recomeçar", proximo: "inicio" }]
  }
};

mostrarCena(cenas.inicio);
